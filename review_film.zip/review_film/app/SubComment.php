<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SubComment extends Model
{
    //
    protected $table = 'subcomment';

	public $timestamps = true;
}
