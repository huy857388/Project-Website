@extends('adminLayout')
@section('adminContent')
	<h1>Chào Mừng Bạn Đến Với Trang Admin</h1>
@endsection
