        <!-- /Header -->
<?php $__env->startSection('content'); ?>
        
        
        
        <!-- Content -->
        <section id="content">
            <div class="container">
            	<!-- Main Content -->
                
                <div class="breadcrumbs column">
                    <p><a href="<?php echo e(url('/')); ?>">Home</a>   \\ Top rated</p>
                </div>
                
                <div class="main-content">
                	
                    <!-- Popular News -->
                	<div class="column-two-third">
                        <?php $__currentLoopData = $ds_film; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($top1==0): ?>
                    	<div class="outertight m-t-no">
                            <div class="badg">
                                <p><a href="#">No.1</a></p>
                            </div>
                            <div class="flexslider">
                                <ul class="slides">
                                    <li>
                                        <img src="<?php echo e(url('public/news_img/'.$news['img'])); ?>" alt="MyPassion"  width="450" height="200"/>
                                    </li>
                                </ul>
                            </div>
                            
                              <h6 class="regular"><a href="<?php echo e(route('showInfo',[$news['TenKhongDau'],$news['slug']])); ?>"><?php echo e($news['title']); ?></a></h6>
                             <span class="meta"> POINT: <?php echo e($news['diem_danh_gia']); ?>  \\   <a href="#"><?php echo e($news['created_at']); ?></a></span>
                            <p><?php echo e($news['content']); ?></p>  </div>
                            <?php $top1=9 ?>
                        
                        <?php elseif($top2==0): ?>
                        <div class="outertight m-r-no m-t-no">
                            <div class="badg">
                                <p><a href="#">No.2</a></p>
                            </div>
                            <div class="flexslider">
                                <ul class="slides">
                                   
                                    <li>
                                        <img src="<?php echo e(url('public/news_img/'.$news['img'])); ?>" alt="MyPassion"  width="450" height="200"/>
                                    </li>
                                </ul>
                            </div>
                            
                            <h6 class="regular"><a href="<?php echo e(route('showInfo',[$news['TenKhongDau'],$news['slug']])); ?>"><?php echo e($news['title']); ?></a></h6>
                            <span class="meta"> POINT: <?php echo e($news['diem_danh_gia']); ?>  \\   <a href="#"><?php echo e($news['created_at']); ?></a></span>
                            <p><?php echo e($news['content']); ?></p>   </div>
                           <?php $top2=9 ?>
                            <div class="outerwide">
                            <ul class="block2">
                        <?php else: ?>
                        
                                <li class="m-r-no">
                                    <a href="<?php echo e(route('showInfo',[$news['TenKhongDau'],$news['slug']])); ?>"><img src="<?php echo e(url('public/news_img/'.$news['img'])); ?>" alt="MyPassion" class="alignleft" width="75px" height="75px" /></a>
                                    <p>
                                        <span>26 May, 2013.</span>
                                        <a href="<?php echo e(route('showInfo',[$news['TenKhongDau'],$news['slug']])); ?>"><?php echo e($news['title']); ?></a>
                                    </p>
                                    <span >POINT: <?php echo e($news['diem_danh_gia']); ?></span>
                                </li> <?php endif; ?>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                

                            </ul>
                        </div>
                      
                        
                       
                    	
                    </div>
                    <!-- /Popular News -->
                    
                </div>
                <!-- /Main Content -->
                
                <!-- Left Sidebar -->
                <?php $__env->stopSection(); ?>
        <!-- / Content -->
        
       
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>