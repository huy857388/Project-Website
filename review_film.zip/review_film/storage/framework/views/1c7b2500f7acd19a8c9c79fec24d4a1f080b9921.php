<div class="pager">
    <ul>
        <?php if($ds_news['current_page'] != 1): ?>
        <li>
            <a href="<?php echo e($ds_news['prev_page_url']); ?>" class="first-page"></a>
        </li>
        <?php endif; ?>
        <?php for($i = 1; $i <=  $ds_news['last_page']; $i++): ?>
        <li>
            <?php if($ds_news['current_page'] != $i): ?>
            <a href="<?php echo e($ds_news['path'].'?page='.$i); ?>"><?php echo $i; ?></a>
            <?php else: ?> 
            <a class="<?php echo ($ds_news['current_page'] == $i)? 'active':''; ?>" href="#"><?php echo $i; ?></a>
            <?php endif; ?>
        </li>
        <?php endfor; ?>
        <?php if($ds_news['current_page'] != $ds_news['last_page']): ?>
        <li>
            <a href="<?php echo e($ds_news['next_page_url']); ?>" class="last-page"></a>
        </li>
        <?php endif; ?>
    </ul>
</div>