 
        <!-- /Header -->
<?php $__env->startSection('content'); ?>
        <!-- Slider -->
        <section id="slider">
            <div class="container">
                <div class="main-slider">
                	<div class="badg">
                    	<p><a href="#">HOT</a></p>
                    </div>
                	<div class="flexslider">
                        <ul class="slides">
                            <?php $__currentLoopData = $ds_hot; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                            <li>
                                <img src="<?php echo e(url('public/news_img/'.$news['img'])); ?>" alt="MyPassion" width="450" height="400"/>
                                <p class="flex-caption"><a href="<?php echo e(route('single',$news['id'])); ?>"><?php echo e($news['title']); ?></a> 
                                <?php echo e($news['content']); ?></p>";
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
                
                <div class="slider2">
                	<div class="badg">
                    	<p><a href="#">ĐỀ CỬ</a></p>
                    </div>
 					<?php $rand_key= array_rand($ds_film,3); ?>
                    <a href="<?php echo e(route('single',$ds_film[$rand_key[0]]['id'])); ?>"><img src="<?php echo e(url('public/news_img/'.$ds_film[$rand_key[0]]['img'])); ?>" alt="MyPassion" width="400" height="250" /></a>
                    <p class="caption"><a href="<?php echo e(route('single',$ds_film[$rand_key[0]]['id'])); ?>"><?php echo e($ds_film[$rand_key[0]]['title']); ?></a><?php echo e($ds_film[$rand_key[0]]['content']); ?> </p>
                </div>
                
                <div class="slider3">
                	<a href="<?php echo e(route('single',$ds_film[$rand_key[1]]['id'])); ?>"><img src="<?php echo e(url('public/news_img/'.$ds_film[$rand_key[1]]['img'])); ?>" alt="MyPassion" width="200" height="150" /></a>
                    <p class="caption"><a href="<?php echo e(route('single',$ds_film[$rand_key[1]]['id'])); ?>"><?php echo e($ds_film[$rand_key[1]]['title']); ?></a></p>
                </div>
                
                <div class="slider3">
                    <a href="<?php echo e(route('single',$ds_film[$rand_key[2]]['id'])); ?>"><img src="<?php echo e(url('public/news_img/'.$ds_film[$rand_key[2]]['img'])); ?>" alt="MyPassion" width="200" height="150" /></a>
                    <p class="caption"><a href="<?php echo e(route('single',$ds_film[$rand_key[2]]['id'])); ?>"><?php echo e($ds_film[$rand_key[2]]['title']); ?></a></p>

                </div>
                
            </div>    
        </section>
        <!-- / Slider -->
        
        <!-- Content -->
        <section id="content">
            <div class="container">
            	<!-- Main Content -->
                <div class="main-content">
                    
                    <!-- World News -->
                    <div class="column-two-third">
                    	<h5 class="line">
                        	<span>TOP RATED MOVIES </span>
                            <div class="navbar">
                                <a id="next2" class="next" href="#"><span></span></a>	
                                <a id="prev2" class="prev" href="#"><span></span></a>
                            </div>
                        </h5>
                        
                        <div class="outerwide" >
                        	<ul class="wnews" id="carousel2">
<!--                             	<li>
                                	<img src="<?php echo e(url('public/img/trash/25.png')); ?>" alt="MyPassion" class="alignleft" />
                                    <h6 class="regular"><a href="#">Blandit Rutrum, Erat et Sagittis. Lorem Ipsum Dolor, Sit Amet Adipsing.</a></h6>
                                    <span class="meta">26 May, 2013.   \\   <a href="#">World News.</a>   \\   <a href="#">No Coments.</a></span>
                                    <p>Blandit rutrum, erat et egestas ultricies, dolor tortor egestas enim, quiste rhoncus sem purus eu sapien. Curabitur a orci nec risus lacinia vehic...</p>
                                </li> -->
                                <!-- chạy dòng for -->
                                <!-- Phần này t làm chưa hoàn chỉnh -->
                                <?php $__currentLoopData = $ds_hot; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <img src="<?php echo e(url('public/news_img/'.$news['img'])); ?>" alt="MyPassion" class="alignleft"  width="600" height="350"/>
                                    <h6 class="regular"><a href="<?php echo e(route('single',$news['id'])); ?>"><?php echo e($news['title']); ?></a></h6>
                                    <span class="meta"><?php echo e($news['created_at']); ?>   \\   <a href="#">World News.</a>   \\   <a href="#">No Coments.</a></span>
                                    <p><?php echo e($news['content']); ?></p>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        
                        <!-- Phần này ôg chưa chú thích nè, t để tạm các tin đề cử -->
                        <div class="outerwide">
                        	<ul class="block2">
                                <?php $__currentLoopData = $ds_decu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <a href="<?php echo e(route('single',$news['id'])); ?>"><img style="width: 75px; height: 75px;" src="<?php echo e(url('public/news_img/'.$news['img'])); ?>" alt="MyPassion" class="alignleft" /></a>
                                    <p>
                                        <span><?php echo e($news['created_at']); ?></span>
                                        <a href="<?php echo e(route('single',$news['id'])); ?>"><?php echo e($news['title']); ?></a>
                                    </p>
                                    <span class="rating"><span style="width:80%;"></span></span>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               <!--  <li>
                                    <a href="#"><img src="<?php echo e(url('public/img/trash/17.png')); ?>" alt="MyPassion" class="alignleft" /></a>
                                    <p>
                                        <span>26 May, 2013.</span>
                                        <a href="#">Blandit Rutrum, Erat et Sagittis.</a>
                                    </p>
                                    <span class="rating"><span style="width:80%;"></span></span>
                                </li>
                                <li class="m-r-no">
                                    <a href="#"><img src="<?php echo e(url('public/img/trash/18.png')); ?>" alt="MyPassion" class="alignleft" /></a>
                                    <p>
                                        <span>26 May, 2013.</span>
                                        <a href="#">Blandit Rutrum, Erat et Sagittis.</a>
                                    </p>
                                    <span class="rating"><span style="width:100%;"></span></span>
                                </li> -->
                            </ul>
                        </div>
                    </div>
                    <!-- /World News -->
                    
                    
                </div>
                <!-- /Main Content -->
                <?php $__env->stopSection(); ?>
                <!-- Left Sidebar -->
                
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>