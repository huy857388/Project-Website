<?php $__env->startSection('adminContent'); ?>
	<h1>Chào Mừng Bạn Đến Với Trang Admin</h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>