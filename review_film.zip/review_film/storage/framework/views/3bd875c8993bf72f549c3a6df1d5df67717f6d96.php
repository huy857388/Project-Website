 <!-- Nav -->
<nav id="nav">
    <ul class="sf-menu">
        <li class="current"><a href="<?php echo e(url('/')); ?>">TRANG CHỦ</a></li>
        <li><a href="danhmuc">HOT</a></li>
        <li><a href="danhmuc">NEW</a></li>
        <li>

        	<a href="#">THỂ LOẠI</a>
            <ul>
                <li><i class="icon-right-open"></i><a href="danhmuc">KINH DỊ</a></li>
                <!-- Viết dòng for để liệt kê thể loại -->
            </ul>
        </li>
        <li><a href="<?php echo e(route('topRating')); ?>">TOP RATED MOVIES</a></li>
        <li><a href="reviews.html">ĐỀ CỬ</a></li>
     <!--   <li>
            <a href="reviews.html">LỊCH.</a>
            <ul>
                <li><i class="icon-right-open"></i><a href="#">LỊCH CHIẾU PHIM.</a>
                    <ul>
                        <li><i class="icon-right-open"></i><a href="#">CGV CINIME.</a></li>
                        <li><i class="icon-right-open"></i><a href="#">BHD CINIME.</a></li>
                        <li><i class="icon-right-open"></i><a href="#">LOTTE CINIME.</a></li>
                    </ul>
                </li> 
                <li><i class="icon-right-open"></i><a href="#">LỊCH TRÌNH.</a></li>
            </ul>
        </li> -->
        <li><a href="<?php echo e(route('login')); ?>">ĐĂNG NHẬP</a></li>  
          <li><a href="<?php echo e(route('register')); ?>">ĐĂNG KÍ</a></li>                        
    </ul>
    
</nav>
<!-- /Nav -->