<!-- /Header -->
<?php $__env->startSection('content'); ?>
<!-- <section id="content"> -->
<section id="<?php echo e($theloai['TenKhongDau']); ?>">
            <div class="container">
                <div class="breadcrumbs column">
                    <!-- thể loại của phim phải fix nhìu chỗ? -->
                	<p><a href="<?php echo e(route('home')); ?>">Home.</a>    \\   <?php echo e($theloai['Ten']); ?>.</p>
                </div>
                <?php if(session('error')): ?>
                    <?php echo e(session('error')); ?>

                <?php endif; ?>
            	<!-- Main Content -->
                <div class="main-content">                    
                    <!-- Single -->
                    <div class="column-two-third single">
                    	<div class="flexslider">
                            <ul class="slides">
                                <!-- 1 news phải kím 3 4 tấm hình lận hả? :)) -->
                                <!-- H t làm tạm 1 hình xuất 3 lần lun đó -->
                                <li>
                                    <img src="<?php echo e(url('public/news_img/'.$news['img'])); ?>" alt="MyPassion" />
                                </li>
                                <li>
                                    <img src="<?php echo e(url('public/news_img/'.$news['img'])); ?>" alt="MyPassion" />
                                </li>
                                <li>
                                    <img src="<?php echo e(url('public/news_img/'.$news['img'])); ?>" alt="MyPassion" />
                                </li>
                            </ul>
                        </div>            
                        <h6 class="title"><?php echo e($news['title']); ?></h6>
                        <span class="meta">Ngày đăng: <?php echo e(date("H \g\iờ i p\h\ú\\t s \g\iâ\y \\n\g\à\y d-m-Y", strtotime($news['created_at']))); ?>   \\ Thể loại:  <a href="<?php echo e(route('theLoai',$theloai_url)); ?>"><?php echo e($theloai['Ten']); ?>. </a></span>
                        <p>Tóm tắt nội dung: <?php echo e($news['short_content']); ?></p>
                        <p>Nội dung: <?php echo e($news['content']); ?></p>
                                                
                        <div class="comments">
                            <h5 class="line"><span>Comments  (<span id="count_cmt"><?php echo e($count_cmt); ?></span>).</span></h5>
                            <ul>
                                <?php $__currentLoopData = $ds_cmt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cmt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <div>
                                        <div class="comment-avatar"><img src="<?php echo e(url('public/img/banner/1.png')); ?>" alt="MyPassion" /></div>
                                        <div class="commment-text-wrap">
                                            <div class="comment-data">
                                                <p>
                                                    <a href="#" class="url"><strong><?php echo e($cmt['name']); ?> </strong></a> &nbsp;
                                                    <?php if(Auth::check()): ?>
                                                    <?php if(Auth::user()->id == $cmt['idUser']): ?>
                                                    <a class="del-cmt" href="javascript:void(0)" >
                                                    <input type="hidden" value="<?php echo e($cmt['id']); ?>">
                                                    Xoá
                                                    </a>    
                                                    <?php endif; ?>
                                                    <?php endif; ?>
                                                     <br /> 
                                                    <span><?php echo e(date("H:i:s d-m-Y", strtotime($cmt['updated_at']))); ?> - <a href="javascript:void(0)" class="comment-reply-link">
                                                    <input type="hidden" value="<?php echo e($cmt['id']); ?>">
                                                    trả lời</a>
                                                    </span>
                                                </p>
                                            </div>
                                            <div class="comment-text"><?php echo e($cmt['NoiDung']); ?></div>
                                        </div>
                                    </div>

                                    <ul class="children">
                                        <?php $__currentLoopData = $cmt['sub_cmt']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_cmt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <div>
                                                <div class="comment-avatar"><img src="<?php echo e(url('public/img//banner/2.png')); ?>" alt="MyPassion" /></div>
                                                <div class="commment-text-wrap">
                                                    <div class="comment-data">
                                                        <p>
                                                            <a href="#" class="url"><?php echo e($sub_cmt['name']); ?></a>
                                                            <?php if(Auth::check()): ?>
                                                            <?php if(Auth::user()->id == $sub_cmt['idUser']): ?>      
                                                            <a class="del-sub-cmt" href="javascript:void(0)" >
                                                            <input type="hidden" value="<?php echo e($sub_cmt['id']); ?>">
                                                            Xoá
                                                            </a>     
                                                            <?php endif; ?>
                                                            <?php endif; ?>
                                                             <br /> 
                                                            <span><?php echo e(date("H:i:s d-m-Y", strtotime($sub_cmt['updated_at']))); ?>

                                                            </span>
                                                        </p>
                                                    </div>
                                                    <div class="comment-text"><?php echo e($sub_cmt['NoiDung']); ?></div>
                                                </div>
                                            </div>
                                        </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <span class="form-reply"></span>
                                    </ul>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>                        
                        <!-- Xử lý security củ chuối :) -->
                        <?php if(Auth::check()): ?> 
                        <div class="comment-form">
                            <h5 class="line"><span>Để lại bình luận tại đây.</span></h5>
                            <form method="post" id="comment-form">
                                <?php echo e(csrf_field()); ?>                               
                                <input type="hidden" name="idBaiRv" value="<?php echo e($news['id']); ?>">
                                <div class="form">
                                    <label>Comment*</label>
                                    <textarea name="content" rows="10" cols="20"></textarea>
                                </div>
                                <input type="button" class="post-comment" value="Đăng bình luận" />
                                <span id="alert"></span>
                            </form>
                        </div>
                        <?php else: ?>
                        <div class="comment-form">
                            <h5 class="line">
                                <span>Để lại bình luận tại đây.</span>                               
                            </h5>
                            <form action="<?php echo e(route('comment')); ?>" method="post">
                                <?php echo e(csrf_field()); ?>                                
                                <input type="hidden" name="idBaiRv" value="<?php echo e($news['id']); ?>">
                                <div class="form">
                                    <label>Comment*</label>
                                    <textarea name="content" rows="10" cols="20"></textarea>
                                </div>
                                <input type="submit" class="post-comment" value="Đăng bình luận" />

                            </form>
                        </div>
                        <?php endif; ?>
                    <script>
                    $(document).ready(function(){
                        //  Ajax cmt cha
                        $("#comment-form input[type=button]").click(function(){
                            f = $("#comment-form").serializeArray();                        
                            // console.log(f[2]['value']);
                            if(f[2]['value'] == ''){
                                console.log("Invalid");  
                                $("#alert").html("<p class='copyright'><strong>Chưa nhập bình luận kìa!</strong></p>");
                            } 
                            else{ 
                                console.log("Valid");
                            $.ajax({
                                async: false,
                                url: "<?php echo e(route('comment')); ?>",
                                type: "post", 
                                dataType: "json",
                                data: f,                                
                                success: function(data){
                                    console.log(data);
                                    // Xử lý format chưa dc
                                    // let format = $.format.date(new Date(data.updated_at), 'HH:mm:ss dd/MM/yyyy');
                                    // console.log(format);
                                    var html = '<li><div><div class="comment-avatar"><img src="<?php echo e(url('public/img/banner/1.png')); ?>" alt="MyPassion" /></div><div class="commment-text-wrap"><div class="comment-data"><p><a href="#" class="url"><strong>' + data.Name + '</strong></a><a class="del-cmt" href="javascript:void(0)" ><input type="hidden" value="' + data.id + '">Xoá</a>  <br /> <span>' + data.updated_at + ' - <a href="javascript:void(0)" class="comment-reply-link"><input type="hidden" value="' + data.id + '">trả lời</a></span></p></div><div class="comment-text">' + data.NoiDung + '</div></div></div><ul class="children"></ul></li>';
                                    $(".comments").children("ul").append(html);
                                },
                                error:function(err){
                                    console.log(err);
                                }
                            });                                                    
                            // reset content cmt
                            $(this).parent()[0].reset();  
                            $("#alert").text('');    
                            // + tổng cmt
                            $("#count_cmt").text(parseInt($("#count_cmt").text()) + 1);

                            $(".del-cmt").click(function(){
                                var r = confirm("Bạn có muốn xoá comment này ko?");
                                if(r == true){
                                    console.log("Xoá nhé!");
                                    
                                    var id_cmt = parseInt($(this).children("input[type=hidden]").val());                                
                                    $.ajax({
                                        url: window.location.origin + "/delete-cmt/" + id_cmt,
                                        type: "get",                                
                                        success:function(data){
                                            console.log(data);
                                        }
                                    });

                                    $(this).parent().parent().parent().parent().remove();
                                }
                                else{
                                    console.log("Tôi chưa xoá cmt của bạn!");
                                }
                            });
                           } 
                        // End Ajax cha
                        });
                    // End jquery
                    });   

                    $(".comment-reply-link").click(function(){
                        // Check login 
                        <?php if(!Auth::check()): ?> window.location.href = window.location.origin + '/login';
                            return;
                        <?php endif; ?>                               
                         var html = '<li><div class="comment-form" id="reply"><h5 class="line"><span>Để lại bình luận tại đây.</span><a class="close-comment" href="javascript:void(0)"><p class="copyright">X</p></a></h5><form id="sub-comment-form"><?php echo e(csrf_field()); ?><input type="hidden" name="idComment" value="' + $(this).children().val() + '"><div class="form"><label>Sub Comment*</label><textarea name="content" rows="10" cols="20" required></textarea></div><input type="button" class="post-comment" value="Đăng bình luận" /><span id="alert"></span></form></div></li>';
                       $(this).parent().parent().parent().parent().parent().siblings().children(".form-reply").html(html);


                       // Sp cho ajax cmt con => định vị trí chèn
                       $(this).parent().parent().parent().parent().parent().siblings().children(".form-reply").before('<span id="cmt' + $(this).children().val() + '"></span>');

                       // Ajax cmt con
                        $("#sub-comment-form input[type=button]").click(function(){
                            f = $("#sub-comment-form").serializeArray();
                            if(f[2]['value'] == ''){
                            console.log("Invalid");  
                            $("#alert").html("<p class='copyright'><strong>Chưa nhập bình luận kìa!</strong></p>");
                            } 
                            else{ 
                            console.log(f);
                            $.ajax({
                                url: "<?php echo e(route('comment')); ?>",
                                type: "post",
                                dataType: "json",
                                data: f,
                                success: function(data){
                                    console.log(data);
                                    var html = '<li><div><div class="comment-avatar"><img src="<?php echo e(url('public/img/banner/2.png')); ?>" alt="MyPassion" /></div><div class="commment-text-wrap">                                                <div class="comment-data"><p><a href="#" class="url">' + data.Name + '</a>   <a class="del-sub-cmt" href="javascript:void(0)" ><input type="hidden" value="' + data.id + '">Xoá</a> <br />                 <span>' + data.updated_at + '</span></p></div><div class="comment-text">' + data.NoiDung + '</div></div></div></li>';
                                    $("#cmt" + data.idComment).before(html);
                                    $(this).remove();
                                }
                            });
                            // cmt xog xoá form => tránh BUG :D
                            $("#sub-comment-form").parent().remove();
                            // cộng tổng cmt
                            $("#count_cmt").text(parseInt($("#count_cmt").text()) + 1);

                            $(".del-sub-cmt").click(function(){
                                var r = confirm("Bạn có muốn xoá sub comment này ko?");
                                if(r == true){
                                    console.log("Xoá nhé!");
                                    
                                    var id_sub_cmt = parseInt($(this).children("input[type=hidden]").val());                                
                                    console.log(id_sub_cmt);
                                    // $.ajax({
                                    //     url: window.location.origin + "/delete-sub-cmt/" + id_sub_cmt,
                                    //     type: "get",                                
                                    //     success:function(data){
                                    //         console.log(data);
                                    //     }
                                    // });

                                    // $(this).parent().parent().parent().parent().remove();
                                }
                                else{
                                    console.log("Tôi chưa xoá cmt của bạn!");
                                }
                            }); 

                            }


                        // End Ajax con
                        }); 

                        $(".close-comment").click(function(){    
                            $(this).parent().parent().remove();
                        });                                              
                    // End reply link
                    }); 

                    $(".del-cmt").click(function(){
                        var r = confirm("Bạn có muốn xoá comment này ko?");
                        if(r == true){
                            console.log("Xoá nhé!");
                            
                            var id_cmt = parseInt($(this).children("input[type=hidden]").val());                                
                            $.ajax({
                                url: window.location.origin + "/delete-cmt/" + id_cmt,
                                type: "get",                                
                                success:function(data){
                                    console.log(data);
                                }
                            });

                            $(this).parent().parent().parent().parent().remove();
                        }
                        else{
                            console.log("Tôi chưa xoá cmt của bạn!");
                        }
                    }); 

                    $(".del-sub-cmt").click(function(){
                        var r = confirm("Bạn có muốn xoá sub comment này ko?");
                        if(r == true){
                            console.log("Xoá nhé!");
                            
                            var id_sub_cmt = parseInt($(this).children("input[type=hidden]").val());                                
                            console.log(id_sub_cmt);
                            // $.ajax({
                            //     url: window.location.origin + "/delete-sub-cmt/" + id_sub_cmt,
                            //     type: "get",                                
                            //     success:function(data){
                            //         console.log(data);
                            //     }
                            // });

                            // $(this).parent().parent().parent().parent().remove();
                        }
                        else{
                            console.log("Tôi chưa xoá cmt của bạn!");
                        }
                    });                                                   
                    </script>                   
                    <!-- /Single -->                                          
                </div>               
            </div>

            <?php $__env->stopSection(); ?>
        
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>