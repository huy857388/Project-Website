        <!-- /Header -->
<?php $__env->startSection('content'); ?>                        
        <!-- Content -->
        <!-- <section id="content"> -->
        <section id="<?php echo e($theloai_url); ?>">
            <div class="container">
            	<!-- Main Content -->                
                <div class="breadcrumbs column">
                	<p><a href="<?php echo e(url('/')); ?>">Home.</a>   \\   <?php echo e($theloai_url); ?></p>
                </div>
                
                <div class="main-content">
                	   
                    <!-- Popular News -->
                	<div class="column-two-third">
                        <?php if(!empty($first_news)): ?>
                    	<div class="outertight m-t-no">
                            <div class="badg">
                                <p><a href="<?php echo e(route('topComment')); ?>">TOP COMMENT</a></p>
                            </div>
                            <div class="flexslider">
                                <ul class="slides">
                                    <li>
                                        <img src="<?php echo e(url('public/news_img/'.$first_news['img'])); ?>" alt="<?php echo e(url('public/news_img/'.$first_news['img'])); ?>" width="450" height="200" />
                                    </li>
                                     <li>
                                        <img src="<?php echo e(url('public/news_img/'.$first_news['img'])); ?>" alt="<?php echo e(url('public/news_img/'.$first_news['img'])); ?>" width="450" height="200" />
                                    </li>
                                     <li>
                                        <img src="<?php echo e(url('public/news_img/'.$first_news['img'])); ?>" alt="<?php echo e(url('public/news_img/'.$first_news['img'])); ?>" width="450" height="200" />
                                    </li>
                                </ul>

                            </div>
                           
                            <h6 class="regular"><a href="<?php echo e(route('showInfo',[$first_news['TenKhongDau'],$first_news['slug']])); ?>"><?php echo e($first_news['title']); ?></a></h6>
                            <span class="meta">Ngày cập nhật: <?php echo e(date("d-m-Y", strtotime($first_news['updated_at']))); ?>   \\   <a href="#"><?php echo e($first_news['count_cmt']); ?> Coments.</a></span>
                            <p><?php echo e($first_news['content']); ?></p>
                        </div>
                         <?php endif; ?>
                         <?php if(!empty($second_news)): ?>
                        <div class="outertight m-r-no m-t-no">
                            <div class="badg">
                                <p><a href="<?php echo e(route('topComment')); ?>">TOP COMMENT</a></p>
                            </div>
                            <div class="flexslider">
                                <ul class="slides">
                                    <li>
                                        <img src="<?php echo e(url('public/news_img/'.$second_news['img'])); ?>" alt="<?php echo e(url('public/news_img/'.$second_news['img'])); ?>" width="450" height="200" />
                                    </li>
                                    <li>
                                        <img src="<?php echo e(url('public/news_img/'.$second_news['img'])); ?>" alt="<?php echo e(url('public/news_img/'.$second_news['img'])); ?>"  width="450" height="200"/>
                                    </li>
                                    <li>
                                        <img src="<?php echo e(url('public/news_img/'.$second_news['img'])); ?>" alt="<?php echo e(url('public/news_img/'.$second_news['img'])); ?>"  width="450" height="200"/>
                                    </li>
                                    
                                </ul>
                            </div>
                            
                            <h6 class="regular"><a href="<?php echo e(route('showInfo',[$second_news['TenKhongDau'],$second_news['slug']])); ?>"><?php echo e($second_news['title']); ?></a></h6>
                            <span class="meta">Ngày cập nhật: <?php echo e(date("d-m-Y", strtotime($second_news['updated_at']))); ?>   \\   <a href="#"><?php echo e($second_news['count_cmt']); ?> Coments.</a></span>
                            <p><?php echo e($second_news['content']); ?></p>
                        </div>
                        <?php endif; ?>
                        <?php if(empty($ds_news)): ?> 
                            <p>Ko có tin nào ở thể loại này cả!</p>
                        <?php else: ?>
                        <div class="outerwide">
                        	<ul class="block2">
                               
                                <?php $__currentLoopData = $ds_news['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="m-r-no">
                                    <a href="<?php echo e(route('showInfo',[$news['TenKhongDau'],$news['slug']])); ?>"><img src="<?php echo e(url('public/news_img/'.$news['img'])); ?>" alt="<?php echo e(url('public/news_img/'.$news['img'])); ?>" class="alignleft" width="100px" height="100px" /></a>
                                    <p>
                                        <span>Ngày cập nhật: <?php echo e(date("d-m-Y", strtotime($news['updated_at']))); ?> </span>
                                        <a href="<?php echo e(route('showInfo',[$news['TenKhongDau'],$news['slug']])); ?>"><?php echo e($news['title']); ?></a>
                                    </p>                                        
                                    <span class="rating"><span style="width:100%;"></span></span>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                             
                            </ul>
                        </div>
                        
                        <!-- <div class="pager">
                            <ul>
                            	<li><a href="#" class="first-page"></a></li>
                                <li><a href="#">1</a></li>
                                <li><a href="#">2</a></li>
                                <li><a href="#" class="active">3</a></li>
                                <li><a href="#">4</a></li>
                                <li><a href="#">5</a></li>
                                <li><a href="#">6</a></li>
                                <li><a href="#">7</a></li>
                                <li><a href="#" class="last-page"></a></li>
                            </ul>
                        </div> -->
                    	<?php echo $__env->make('layouts.paginating', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <?php endif; ?>  
                    </div>
                    <!-- /Popular News -->
                    
                </div>
                <!-- /Main Content -->
                
                <!-- Left Sidebar -->
                <?php $__env->stopSection(); ?>
        <!-- / Content -->
        
       
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>