<div class="search">
    <form action="#" method="post">
        <input type="text" value="Search." onblur="if(this.value=='') this.value='Search.';" onfocus="if(this.value=='Search.') this.value='';" class="ft"/>
        <input type="submit" value="" class="fs">
    </form>
    <?php if(Auth::check()): ?>
    Chào bạn, <?php echo e(Auth::user()->name); ?> 
    <a href="<?php echo e(route('logout')); ?>"
        onclick="event.preventDefault();
                 document.getElementById('logout-form').submit();">
        Đăng xuất
    </a>

    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
        <?php echo e(csrf_field()); ?>

    </form>
    <?php endif; ?>
</div>

