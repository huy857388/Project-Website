        <!-- /Header -->
<?php $__env->startSection('content'); ?>
        
        
        
        <!-- Content -->
        <!-- <section id="content"> -->
        <section id="<?php echo e($danhmuc); ?>">
            <div class="container">
            	<!-- Main Content -->
                
                <div class="breadcrumbs column">
                    <p><a href="<?php echo e(url('/')); ?>">Home</a>   \\    <?php echo e($danhmuc); ?></p>
                </div>
                
                <div class="main-content">
                	
                    <!-- Popular News -->
                	<div class="column-two-third">
                    	<div class="outertight m-t-no">
                            <div class="flexslider">
                                <ul class="slides">
                                    <li>
                                        <img src="<?php echo e(url('public/news_img/'.$ds_film[0]['img'])); ?>" alt="MyPassion"  width="450" height="200"/>
                                    </li>
                                </ul>
                            </div>
                            
                              <h6 class="regular"><a href="<?php echo e(route('showInfo',[$ds_film[0]['TenKhongDau'],$ds_film[0]['slug']])); ?>"><?php echo e($ds_film[0]['title']); ?></a></h6>
                            <span class="meta"><?php echo e($ds_film[0]['created_at']); ?>   \\   <a href="#">No Coments.</a></span>
                            <p><?php echo e($ds_film[0]['content']); ?></p>  </div>
                        
                        <div class="outertight m-r-no m-t-no">
                            <div class="flexslider">
                                <ul class="slides">
                                   
                                    <li>
                                        <img src="<?php echo e(url('public/news_img/'.$ds_film[1]['img'])); ?>" alt="MyPassion"  width="450" height="200"/>
                                    </li>
                                </ul>
                            </div>
                            
                            <h6 class="regular"><a href="<?php echo e(route('showInfo',[$ds_film[1]['TenKhongDau'],$ds_film[1]['slug']])); ?>"><?php echo e($ds_film[1]['title']); ?></a></h6>
                            <span class="meta"><?php echo e($ds_film[1]['created_at']); ?>   \\   <a href="#">No Coments.</a></span>
                            <p><?php echo e($ds_film[1]['content']); ?></p>   </div>
                        
                        <div class="outerwide">
                        	<ul class="block2">
                                <?php $len=count($ds_film)?>
                                 <?php for($i = 2; $i < $len; $i++): ?>
                                <li class="m-r-no">
                                    <a href="<?php echo e(route('showInfo',[$ds_film[$i]['TenKhongDau'],$ds_film[$i]['slug']])); ?>"><img src="<?php echo e(url('public/news_img/'.$ds_film[$i]['img'])); ?>" alt="MyPassion" class="alignleft" width="100px" height="100px" /></a>
                                    <p>
                                        <span>26 May, 2013.</span>
                                        <a href="<?php echo e(route('showInfo',[$ds_film[$i]['TenKhongDau'],$ds_film[$i]['slug']])); ?>"><?php echo e($ds_film[$i]['title']); ?></a>
                                    </p>
                                    <span class="rating"><span style="width:100%;"></span></span>
                                </li>
                                <?php endfor; ?>
                               

                            </ul>
                        </div>
                        
                        <div class="pager">
                            <ul>
                            	<li><a href="#" class="first-page"></a></li>
                                <li><a href="#">1</a></li>
                                <li><a href="#">2</a></li>
                                <li><a href="#" class="active">3</a></li>
                                <li><a href="#">4</a></li>
                                <li><a href="#">5</a></li>
                                <li><a href="#">6</a></li>
                                <li><a href="#">7</a></li>
                                <li><a href="#" class="last-page"></a></li>
                            </ul>
                        </div>
                    	
                    </div>
                    <!-- /Popular News -->
                    
                </div>
                <!-- /Main Content -->
                
                <!-- Left Sidebar -->
                <?php $__env->stopSection(); ?>
        <!-- / Content -->
        
       
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>