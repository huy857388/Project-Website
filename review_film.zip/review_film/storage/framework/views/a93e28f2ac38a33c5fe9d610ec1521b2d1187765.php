 <!-- Nav -->
<nav id="nav">
    <ul class="sf-menu">
        <li id="stt-home"><a href="<?php echo e(url('/')); ?>">TRANG CHỦ</a></li>
        <li id="stt-hot"><a href="<?php echo e(route('danhmuc','HOT')); ?>">HOT</a></li>
        <li id="stt-new"><a href="<?php echo e(route('danhmuc','NEW')); ?>">NEW</a></li>
        <li id="stt-theloai">

        	<a href="#">THỂ LOẠI</a>
            <ul>
                <!-- Viết dòng for để liệt kê thể loại -->
                <?php $__currentLoopData = $ds_theloai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $theloai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li id="stt-<?php echo e($theloai['TenKhongDau']); ?>"><i class="icon-right-open"></i><a href="<?php echo e(route('theLoai',$theloai['TenKhongDau'])); ?>"><?php echo e($theloai['Ten']); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </li>
        <!-- <<<<<<< HEAD -->
        <li><a href="<?php echo e(route('toprated')); ?>">TOP RATED MOVIES</a></li>
        <li id="stt-topcomment"><a href="<?php echo e(route('topComment')); ?>">TOP 10 COMMENT MOVIES</a></li>
<!-- ======= -->        
<!-- >>>>>>> 25bc3299c84c5fb3693d5f63be7bf11d9c82c972 -->
        <!-- <li><a href="reviews.html">ĐỀ CỬ</a></li> -->
    <!--    <li>
            <a href="reviews.html">LỊCH.</a>
            <ul>
                <li><i class="icon-right-open"></i><a href="#">LỊCH CHIẾU PHIM.</a>
                    <ul>
                        <li><i class="icon-right-open"></i><a href="#">CGV CINIME.</a></li>
                        <li><i class="icon-right-open"></i><a href="#">BHD CINIME.</a></li>
                        <li><i class="icon-right-open"></i><a href="#">LOTTE CINIME.</a></li>
                    </ul>
                </li> 
                <li><i class="icon-right-open"></i><a href="#">LỊCH TRÌNH.</a></li>
            </ul>
        </li>
 -->
        <?php if(Auth::check()): ?>
        Chào bạn, <?php echo e(Auth::user()->name); ?>

        <a href="<?php echo e(route('logout')); ?>"
            onclick="event.preventDefault();
                     document.getElementById('logout-form').submit();">
            Đăng xuất
        </a>
       
        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
            <?php echo e(csrf_field()); ?>

        </form>
        <?php else: ?>
            <li><a href="<?php echo e(route('login')); ?>">ĐĂNG NHẬP</a></li>  
            <li><a href="<?php echo e(route('register')); ?>">ĐĂNG KÍ</a></li>  
        <?php endif; ?>                              
    </ul>
    
</nav>
<!-- /Nav -->